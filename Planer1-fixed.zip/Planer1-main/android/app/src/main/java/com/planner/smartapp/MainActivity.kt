package com.planner.smartapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject
import java.io.OutputStream

class MainActivity : ComponentActivity() {

    lateinit var webView: WebView
    lateinit var bridge: AndroidBridge

    // System insets tracking in px
    var insetsTop: Int = 0
    var insetsBottom: Int = 0
    var insetsLeft: Int = 0
    var insetsRight: Int = 0

    private var pendingBackupContent: String? = null

    // Notification permission launcher (Android 13+)
    val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        val status = if (isGranted) "granted" else "denied"
        webView.post {
            webView.evaluateJavascript(
                "if (window.onNativeNotificationPermissionResult) window.onNativeNotificationPermissionResult($isGranted, '$status');",
                null
            )
        }
    }

    // Audio file picker launcher (Storage Access Framework)
    val audioPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val uri: Uri? = result.data?.data
            if (uri != null) {
                try {
                    // Take persistable permission so it survives app restarts
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }

                val displayName = getFileNameFromUri(uri) ?: "audio_selected.mp3"
                webView.post {
                    webView.evaluateJavascript(
                        "if (window.onNativeAudioFilePicked) window.onNativeAudioFilePicked('${uri}', '${displayName.replace("'", "\\'")}');",
                        null
                    )
                }
                return@registerForActivityResult
            }
        }
        // Cancelled
        webView.post {
            webView.evaluateJavascript(
                "if (window.onNativeAudioFilePicked) window.onNativeAudioFilePicked(null, null);",
                null
            )
        }
    }

    // Backup document creation launcher (Storage Access Framework)
    val createBackupLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val uri: Uri? = result.data?.data
            if (uri != null && pendingBackupContent != null) {
                try {
                    val outputStream: OutputStream? = contentResolver.openOutputStream(uri)
                    outputStream?.use { stream ->
                        stream.write(pendingBackupContent!!.toByteArray(Charsets.UTF_8))
                        stream.flush()
                    }
                    pendingBackupContent = null
                    webView.post {
                        webView.evaluateJavascript(
                            "if (window.onNativeBackupFileSaved) window.onNativeBackupFileSaved(true, '${uri}');",
                            null
                        )
                    }
                    return@registerForActivityResult
                } catch (e: Exception) {
                    pendingBackupContent = null
                    val err = e.localizedMessage ?: "Unknown I/O error"
                    webView.post {
                        webView.evaluateJavascript(
                            "if (window.onNativeBackupFileSaved) window.onNativeBackupFileSaved(false, '${err.replace("'", "\\'")}');",
                            null
                        )
                    }
                    return@registerForActivityResult
                }
            }
        }
        pendingBackupContent = null
        webView.post {
            webView.evaluateJavascript(
                "if (window.onNativeBackupFileSaved) window.onNativeBackupFileSaved(false, 'عملیات ذخیره فایل لغو شد');",
                null
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 1. Enable Full Edge-to-Edge Display
        WindowCompat.setDecorFitsSystemWindows(window, false)

        // 2. Initialize Notification Channels
        NotificationHelper.createNotificationChannels(this)

        // 3. Setup WebView
        webView = WebView(this)
        setContentView(webView)

        setupWindowInsets()
        setupWebView()

        // 4. Load application entry point
        try {
            val assetsList = assets.list("public") ?: emptyArray()
            if (assetsList.contains("index.html")) {
                webView.loadUrl("file:///android_asset/public/index.html")
            } else {
                webView.loadUrl("file:///android_asset/dist/index.html")
            }
        } catch (e: Exception) {
            webView.loadUrl("file:///android_asset/public/index.html")
        }
    }

    private fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(webView) { view, insets ->
            val systemBars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                WindowInsetsCompat.Type.displayCutout()
            )
            val density = resources.displayMetrics.density
            insetsTop = (systemBars.top / density).toInt()
            insetsBottom = (systemBars.bottom / density).toInt()
            insetsLeft = (systemBars.left / density).toInt()
            insetsRight = (systemBars.right / density).toInt()

            // Pass updated insets to web application CSS variables
            webView.post {
                val script = """
                    document.documentElement.style.setProperty('--safe-area-top', '${insetsTop}px');
                    document.documentElement.style.setProperty('--safe-area-bottom', '${insetsBottom}px');
                    document.documentElement.style.setProperty('--safe-area-left', '${insetsLeft}px');
                    document.documentElement.style.setProperty('--safe-area-right', '${insetsRight}px');
                """.trimIndent()
                webView.evaluateJavascript(script, null)
            }

            WindowInsetsCompat.CONSUMED
        }
    }

    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.cacheMode = WebSettings.LOAD_DEFAULT

        bridge = AndroidBridge(this, webView)
        webView.addJavascriptInterface(bridge, "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                // Handle external links or custom intents
                if (url.startsWith("intent://") || url.startsWith("tel:") || url.startsWith("mailto:")) {
                    try {
                        val intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                        startActivity(intent)
                        return true
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                return false
            }
        }

        webView.webChromeClient = WebChromeClient()
    }

    fun setPendingBackup(content: String) {
        pendingBackupContent = content
    }

    private fun getFileNameFromUri(uri: Uri): String? {
        var name: String? = null
        val cursor = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val index = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (index >= 0) {
                    name = it.getString(index)
                }
            }
        }
        return name
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
