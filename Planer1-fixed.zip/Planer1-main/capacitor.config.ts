import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.planner.smartapp',
  appName: 'Planer1',
  webDir: 'dist',
  bundledWebRuntime: false,
};

export default config;
